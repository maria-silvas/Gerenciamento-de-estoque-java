# gerenciamento-estoque-java
Exercicio Extra POO - Gerenciamento de Estoque - Aplicação de Classes em Java

Crie um programa para gerenciamento do estoque de uma verdureira.

Para isso será necessário criar os produtos, os locais onde serão armazenados com suas quantidades e os fabricantes/fornecedores de cada produto.

O programa devera conter:
fabricante
    Id
    Nome

Produto
   Id
   Descrição
   Tamanho
   Cor
   Fabricante

Local de Estoque
   Id
   Detalhes
   Produto
   Quantidade

Deverá ser criado um programa para cadastro e listagem de cada uma dessas informações, sendo em um banco de dados temporário